# Generated code do not commit.
file(TO_CMAKE_PATH "C:\\flutter\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\flutterr\\flutter_assignment_1\\lecture 7-8\\practice\\practice" PROJECT_DIR)

set(FLUTTER_VERSION "0.1.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=C:\\flutter\\flutter"
  "PROJECT_DIR=C:\\flutterr\\flutter_assignment_1\\lecture 7-8\\practice\\practice"
  "FLUTTER_ROOT=C:\\flutter\\flutter"
  "FLUTTER_EPHEMERAL_DIR=C:\\flutterr\\flutter_assignment_1\\lecture 7-8\\practice\\practice\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\flutterr\\flutter_assignment_1\\lecture 7-8\\practice\\practice"
  "FLUTTER_TARGET=C:\\flutterr\\flutter_assignment_1\\lecture 7-8\\practice\\practice\\lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9CVUlMRF9OQU1FPTAuMS4w,RkxVVFRFUl9CVUlMRF9OVU1CRVI9MQ==,RkxVVFRFUl9WRVJTSU9OPTMuNDcuNQ==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049NmExOWNjYTU2NA==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049YWY3ZTc5NmUxNg==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMy40"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=C:\\flutterr\\flutter_assignment_1\\lecture 7-8\\practice\\practice\\.dart_tool\\package_config.json"
)
